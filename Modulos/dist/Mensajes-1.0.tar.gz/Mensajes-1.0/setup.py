from setuptools import setup

setup(
    name='Mensajes',
    version='1.0',
    description='Un paquete para saludar',
    author='Josavicente',
    author_email='jvicenpe@gmail.com',
    url='http://www.google.es',
    packages=['mensajes', 'mensajes.hola'],
    scripts=['test.py']
)