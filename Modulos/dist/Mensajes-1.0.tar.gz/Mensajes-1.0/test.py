from mensajes.hola.saludos import *

saludar()
Saludo()
